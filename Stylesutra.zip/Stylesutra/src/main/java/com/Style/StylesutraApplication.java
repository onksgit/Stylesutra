package com.Style;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class StylesutraApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(StylesutraApplication.class, args);
	}

}
